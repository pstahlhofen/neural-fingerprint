# ubi-cluster-use
This repo is designed to get you startet working on the Uni Bielefeld compute cluster. It also contains example scripts.

## Table of Contents  
[Setup](#setup)  
[Slurm](#slurm)  
[Nodes](#nodes)

<a name="setup"/>

## Setup
### Access
First you need to request access from the RBG support. Simply send an email containing your techfak-login to:
```
support@techfak.net
```
Note: If you are not Citec-staff and need the cluster for writing your thesis, either have your supervisor write the email on your behalf or mention that you are writing a thesis for them in your mail. 
### Login
Afterwards, you can access the cluster by ssh-ing to the login node:
```
ssh mmuster@login.gpu.cit-ec.net
```
If you are outside the techfak-net and want to access the cluster you need to ssh to i.e. ```compute.techfak.de``` first.
After logging in, you should be inside your home directory on the cluster ```/media/compute/homes/mmuster```.
### Environment
The cluster runs the standard netboot installation. There are additional modules you can load. Most notably Cuda.
To check what is available run:
```
module avail
```
In ```example_module_load.sbatch``` you can see how to load Cuda 9 to be used by your script.
Anything else you need to setup yourself. 
If you are using python I recommend [anaconda](https://www.anaconda.com/distribution/) to keep your environment on the cluster easy to maintain. Alternatively use ```virtuelenv```.
### File Sync
To keep your code updated I think it is best to just use a git repo.
For other data, i.e. training data, use rsync:
```
rsync <Path>/mydata -avz mmuster@login.gpu.cit-ec.net:
```

The compute home is also accessible via ```files.techfak.de:/media/compute/homes/mmuster``` outside the TechFak net.

<a name="slurm"/>

## Slurm
[Slurm](https://slurm.schedmd.com/) is the scheduler running on the cluster. You need to start and schedule your jobs via slurm.
### SBATCH
#### Basic Script
To get started create your own sbatch-script. Here you can specify what your job is and which ressources it needs.

```example.sbatch```:
```
#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name=train_example
#SBATCH --time=5:00:00

srun train_example.sh
```
In this example we request one gpu for five hours for our job ``` train_example```.  
Remember to give your sbatch and sh files execute permissions with
```
chmod +x example.sbatch train_example.sh
```

You can schedule your job by using
```
sbatch example.sbatch
```
Using
```
squeue
```
you should see your job in the list
```
             JOBID PARTITION     NAME     USER ST       TIME  NODES NODELIST(REASON)
              2115       gpu script.s   **      PD       0:00     1 (Resources)
              2116       gpu train_ex   mmuster PD       0:00     1 (Priority)
              2118       cpu isy-run.   **      PD       0:00     1 (Resources)
              1816       cpu     bash   **      R 14-02:39:13     1 hefty
              1931       gpu script.s   **      R 5-08:12:19      1 handy
              1933       gpu script.s   **      R 5-07:55:56      1 handy
              1964       cpu     bash   **      R 4-06:42:14      1 handy
            2016_6       gpu   flow2a   **      R    4:40:27      1 papaschlumpf
              2047       cpu     bash   **      R 2-04:47:06      1 handy
              2062       cpu     bash   **      R 2-03:49:09      1 papaschlumpf
              2066       cpu     bash   **      R 2-03:44:27      1 papaschlumpf
              2076       gpu batchpro   **      R   15:58:47      1 clumsy
              2077       gpu script.s   **      R   15:54:00      1 clumsy
              2110       gpu script.s   **      R      22:28      1 schlaubi
              2112       gpu script.s   **      R      20:22      1 hefty
              2113       gpu script.s   **      R      19:49      1 hefty
              2114       gpu script.s   **      R      16:09      1 schlaubi

```
Right now your job is not running yet. It will be as soon as your requested ressources are available.
You can see the output of your ```train_example.sh``` script in your home directory in ```slurm-2116.out```.
If you want to cancel your job use
```
scancel $JOBID
```
When your job is running you can see on which node in the last column. For the list of available nodes on the cluster see [Nodes](#nodes).

#### Mail Notifications
You can be informed about the status of your job via email by adding
```
#SBATCH --mail-user=mmuster@techfak.uni-bielefeld.de
#SBATCH --mail-type=END
```
to your sbatch-script. Only techfak addresses work. In this example you will recieve an email when your job ends that means either fails, completes or runs out of time. See https://slurm.schedmd.com/sbatch.html for a list of available mail types.

#### Ressource Request
You can be more specific in requesting ressources. So if you know you need a lot of vram your can ask for a tesla gpu (or for less if you know you do not need that much).
```
#SBATCH --gres=gpu:tesla:1
```
You should monitor how much ressources you actually need so you avoid requesting too much and taking away ressources from others. 
On the flipside you should also not request too little. If you request to use one cpu the cluster thinks you need only one and puts more jobs on the node. If you actually use 20 then everything will be slower for everyone.
Monitor how much cpus you need and request the right number using
```
#SBATCH --cpus-per-task=20
```
You can monitor your processes by ssh-ing to the node you got assigned (check with ```squeue```) and using i.e. ```htop```.

#### Arrays
If you want to start mulitple instances of the same process you can use job arrays to submit all of them at once without blocking too many ressources.

```array_example.sbatch```:
```
#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH --job-name=train_example
#SBATCH --time=5:00:00
#SBATCH --array 0-14%3

srun train_example.sh
```
In this example 15 instances of the same job are submitted but only a maximum of 3 will be running at the same time.
The indices you give (here 0-14) will show up in your job id and can be modified (see sbatch documentation: [SBTACH](https://slurm.schedmd.com/sbatch.html)).

<a name="nodes"/>

## Nodes
1. **node1.gpu.cit-ec.net (papaschlumpf)**  
   2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
   2 x Nvidia Tesla P-100 16G  
   256 GB RAM  

2. **node2.gpu.cit-ec.net (schlumpfine)**  
    2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
    2 x Nvidia Tesla P-100 16G  
    256 GB RAM  

3. **node3.gpu.cit-ec.net (schlaubi)**  
    2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
    2 x Nvidia GeForce GTX 1080 TI 12G  
    128 GB RAM  

4. **node4.gpu.cit-ec.net (hefty)**  
    2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
    2 x Nvidia GeForce GTX 1080 TI 12G  
    128 GB RAM  

5. **node5.gpu.cit-ec.net (clumsy)**  
    2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
    2 x Nvidia GeForce GTX 1080 TI 12G  
    128 GB RAM  

6. **node6.gpu.cit-ec.net (handy)**  
    2 x Intel Xeon(R) CPU E5-2640 v4 @ 2.4 GHz  
    2 x Nvidia GeForce GTX 1080 TI 12G  
    128 GB RAM  

7. **node7.gpu.cit-ec.net (azrael)**  
    Intel Xeon(R) CPU E5645 @ 2.4 GHz  
    2 x Nvidia Tesla C2075 6G  
    32 GB RAM  
