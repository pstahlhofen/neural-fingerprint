#!/bin/bash

#Setup your environment. If you use anaconda for example:
export PATH="/media/compute/homes/mmuster/anaconda3/bin:$PATH"

#Run your program. If you use python:
python3 /media/compute/homes/mmuster/myProject/main.py
